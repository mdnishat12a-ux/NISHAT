# Nishat AI

Android starter project for Nishat AI.

## Build in GitHub Actions
1. Upload this project to a GitHub repository.
2. Open **Actions** → **Build Nishat AI APK**.
3. Run the workflow.
4. Download the `NishatAI-debug-apk` artifact.

The app currently uses a local demo response engine. Voice input, URL opening and Bengali text-to-speech are wired through the Android bridge. A real AI API can be added later.
