package com.nishat.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "NishatNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun openUrl(url: String) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) {
            }
        }

        @JavascriptInterface
        fun voice() {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "বলুন…")
                }
                startActivityForResult(intent, 1001)
            } catch (_: Exception) {
                web.evaluateJavascript("window.receiveVoice('ভয়েস ইনপুট চালু করা যায়নি')", null)
            }
        }

        @JavascriptInterface
        fun speak(text: String) {
            val i = Intent(this@MainActivity, SpeechServiceActivity::class.java)
            i.putExtra("text", text)
            startActivity(i)
        }

        @JavascriptInterface
        fun askAI(prompt: String, apiKey: String) {
            Thread {
                val result = requestOpenAI(prompt, apiKey)
                val js = "window.receiveAI(${JSONObject.quote(result)})"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }.start()
        }

        private fun requestOpenAI(prompt: String, apiKey: String): String {
            if (apiKey.isBlank()) return "API key দেওয়া হয়নি। নিচের ⚙️ সেটিংস থেকে OpenAI API key দিন।"
            return try {
                val url = URL("https://api.openai.com/v1/responses")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Content-Type", "application/json")
                }

                val body = JSONObject().apply {
                    put("model", "gpt-5.6-luna")
                    put("input", prompt)
                }.toString()

                conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { it.readText() }
                conn.disconnect()

                if (code !in 200..299) {
                    try {
                        val error = JSONObject(text).optJSONObject("error")
                        "API error: " + (error?.optString("message") ?: "HTTP $code")
                    } catch (_: Exception) {
                        "API error: HTTP $code"
                    }
                } else {
                    extractOutputText(JSONObject(text))
                }
            } catch (e: Exception) {
                "ইন্টারনেট/API সংযোগে সমস্যা: ${e.message ?: "unknown error"}"
            }
        }

        private fun extractOutputText(root: JSONObject): String {
            val output = root.optJSONArray("output") ?: return "AI কোনো উত্তর দেয়নি।"
            val parts = mutableListOf<String>()
            for (i in 0 until output.length()) {
                val item = output.optJSONObject(i) ?: continue
                val content = item.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val part = content.optJSONObject(j) ?: continue
                    if (part.optString("type") == "output_text") {
                        val t = part.optString("text")
                        if (t.isNotBlank()) parts.add(t)
                    }
                }
            }
            return parts.joinToString("\n").ifBlank { "AI কোনো টেক্সট উত্তর দেয়নি।" }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (text != null) {
                web.evaluateJavascript("window.receiveVoice(${JSONObject.quote(text)})", null)
            }
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
