package com.nishat.ai

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale

class SpeechServiceActivity : Activity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent.getStringExtra("text") ?: ""
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("bn", "BD")
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nishat")
            }
        }
        window.decorView.postDelayed({ finish() }, 2500)
    }
    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
